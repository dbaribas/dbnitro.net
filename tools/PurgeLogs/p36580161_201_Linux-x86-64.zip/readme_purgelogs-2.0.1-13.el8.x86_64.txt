----------------------------------------------------------------------
purgeLogs: Archive & Cleanup traces, logs in one command (OL8)
Patch 36580161 - PLACEHOLDER FOR purgelogs (Version: 20241002 - Revision: 2.0.1-13)
(OL8 RPM sha256sum: 2cc19ecb79de3721e59f256e66c2aebdd71b73dad7643555ca010dbab8f47a19)
 
The user documentation is located at MOS: 'purgeLogs: Archive & Cleanup traces, logs in one command (Doc ID 2081655.1)'
--> https://support.oracle.com/epmos/faces/DocumentDisplay?id=2081655.1

The patch consists of one zip file within an RPM.
----------------------------------------------------------------------
